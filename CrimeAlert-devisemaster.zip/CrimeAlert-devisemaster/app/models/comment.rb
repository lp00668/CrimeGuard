class Comment < ApplicationRecord
  belongs_to :location
end
