class Place < ApplicationRecord
end
