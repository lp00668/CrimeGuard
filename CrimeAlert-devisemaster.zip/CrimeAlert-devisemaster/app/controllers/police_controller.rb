class PoliceController < ApplicationController
  def index
  end
end
