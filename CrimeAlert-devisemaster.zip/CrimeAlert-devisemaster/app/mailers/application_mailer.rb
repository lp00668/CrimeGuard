class ApplicationMailer < ActionMailer::Base
  default from: 'crimeguardapp@gmail.com'
  layout 'mailer'
end
